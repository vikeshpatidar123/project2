import pgzrun
from random import randint

apple = Actor("apple")
pineapple = Actor("pineapple")
orange = Actor("orange")
goldapple = Actor("golden_apple")

score = 0
applehit = ["Nice shot!!", "You got it!!!", "SHOOT!!!"]

def draw():
    screen.clear()
    apple.draw()
    goldapple.draw()
    orange.draw()
    pineapple.draw()
    
    screen.draw.text("Your score is: " + str(score), topleft=(10,10))

def place_fruits():
    apple.x = randint(10, 800)
    apple.y = randint(10, 600)

    orange.x = randint(10, 800)
    orange.y = randint(10, 600)

    pineapple.x = randint(10, 800)
    pineapple.y = randint(10, 600)

    if randint(1, 20) == 20:
        goldapple.x = randint(10, 800)
        goldapple.y = randint(10, 600)
    else:
        goldapple.x = -100

def on_mouse_down(pos):
    global score
    
    if apple.collidepoint(pos):
        score += 3
        print(applehit[randint(0, (len(applehit) - 1))] + " +3 point")
        place_fruits()
    elif orange.collidepoint(pos):
        score += 1
        print(applehit[randint(0, (len(applehit) - 1))] + " +1 points")
        place_fruits()
    elif pineapple.collidepoint(pos):
        score += 2
        print(applehit[randint(0, (len(applehit) - 1))] + " +2 point")
        place_fruits()
    elif goldapple.collidepoint(pos):
        score += 50
        print("GOLD APPLE HIT!!! +50 point")
        place_fruits()
    else:
        score -= 5
        print("You missed!!! -5 points")
        place_fruits()

place_fruits()

pgzrun.go()
